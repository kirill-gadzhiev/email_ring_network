# VueJS

Open *src/App.vue* and replace line 2 with

    'Hello Frontend Workflow';

In Gotron **root** dir type

    npm run build-vue
    go build
    ./gotron

Reload updated index.js using 'r' key.
