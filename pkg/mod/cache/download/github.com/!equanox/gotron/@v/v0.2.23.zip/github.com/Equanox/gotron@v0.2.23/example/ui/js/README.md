# Pure Javascript

Open *src/app.js* and replace line 6 with

    topic.innerHTML = 'Hello Frontend Workflow';

In Gotron **root** dir type

    npm run build
    go build
    ./gotron

Reload updated index.js using 'r' key.
