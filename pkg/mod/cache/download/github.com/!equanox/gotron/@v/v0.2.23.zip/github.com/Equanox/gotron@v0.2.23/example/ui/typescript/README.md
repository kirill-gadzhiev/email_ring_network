# Typescript-React

A boilerplate to start ui development with typescript and react.

### Example
Open *src/app.tsx* and replace line 10 with

    Hello Gotron / Typescript Workflow

In Gotron **root** dir type

    npm run build:typescript
    go build
    ./gotron

**Hint:** On the first build it is necessary that typescript/webpack will be executed two times because of the style-loader.

Reload updated index.js using 'r' key.
