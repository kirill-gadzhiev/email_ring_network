# React

Open *src/app.js* and replace line 10 with

    Hello Gotron / React Workflow

In Gotron **root** dir type

    npm run build:react
    go build
    ./gotron

Reload updated index.js using 'r' key.
